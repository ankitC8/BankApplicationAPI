package com.bankapp.application.servicetests;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.entity.Transaction;
import com.bankapp.application.repository.TransactionRepository;
import com.bankapp.application.service.TransactionServiceImpl;

@SpringBootTest(classes = TransactionServiceTest.class)
public class TransactionServiceTest {

	@Mock
	TransactionRepository transactionRepository;

	@InjectMocks
	TransactionServiceImpl transactionService;

	public List<Transaction> transactionList;

	@Test
	@Order(1)
	void TestForGetAllTransaction() {
		transactionList = new ArrayList<Transaction>();
		// Transaction(int, double, TransactionType, double, LocalDate)
		transactionList.add(new Transaction(2, 2000, TransactionType.valueOf("DEPOSIT"), 8000, LocalDate.now()));
		transactionList.add(new Transaction(3, 1500, TransactionType.valueOf("DEPOSIT"), 8990, LocalDate.now()));
		transactionList.add(new Transaction(3, 6500, TransactionType.valueOf("WITHDRAW"), 2997, LocalDate.now()));

		when(transactionRepository.findAll()).thenReturn(transactionList);

		Assertions.assertEquals(3, transactionService.getAllTransactions().size());
	}
}
