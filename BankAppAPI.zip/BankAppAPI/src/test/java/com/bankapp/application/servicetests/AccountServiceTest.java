package com.bankapp.application.servicetests;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.bankapp.application.constants.AccountType;
import com.bankapp.application.constants.StatusType;
import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.entity.*;
import com.bankapp.application.repository.AccountRepository;
import com.bankapp.application.service.AccountServiceImpl;

@SpringBootTest(classes = AccountServiceTest.class)
public class AccountServiceTest {

	@Mock
	AccountRepository accountRepository;

	@InjectMocks
	AccountServiceImpl accountService;

	// public static List<Account> accountList;
	public static List<Transaction> transactionList;
	static {
		transactionList = new ArrayList<Transaction>();
		// Transaction(int, double, TransactionType, double, LocalDate)
		transactionList.add(new Transaction(1, 2000, TransactionType.valueOf("DEPOSIT"), 8000, LocalDate.now()));
		transactionList.add(new Transaction(2, 1500, TransactionType.valueOf("DEPOSIT"), 8990, LocalDate.now()));
		transactionList.add(new Transaction(3, 6500, TransactionType.valueOf("WITHDRAW"), 2997, LocalDate.now()));
		transactionList.add(new Transaction(4, 7500, TransactionType.valueOf("WITHDRAW"), 4597, LocalDate.now()));

		// accountList=new ArrayList<Account>();

		// Account(long, double, AccountType, StatusType, List<Transaction>)
		/*
		 * accountList.add(new
		 * Account(122221,30000,AccountType.SAVINGS,StatusType.ACTIVE,transactionList));
		 * accountList.add(new Account(122221,30000,AccountType.SAVINGS,StatusType.ACTIVE,transactionList));
		 * accountList.add(new
		 * Account(122221,30000,AccountType.SAVINGS,StatusType.ACTIVE,transactionList));
		 * accountList.add(new
		 * Account(122221,30000,AccountType.SAVINGS,StatusType.ACTIVE,transactionList));
		 * accountList.add(new
		 * Account(122221,30000,AccountType.SAVINGS,StatusType.ACTIVE,transactionList));
		 */
	}

	@Test
	@Order(1)
	void testDepositForCurrentAccount() {
		double amountToBeDeposited1=50000;
		double amountToBeDeposited2=500;
		
		long accountId=677474740;
		Account account=new Account(accountId,30000,AccountType.CURRENT,StatusType.ACTIVE,transactionList);
		
		when(accountRepository.findById(accountId).get()).thenReturn(account);
		
		double currentBalance=account.getCurrentBalance();
		double updatedBalance=currentBalance+amountToBeDeposited1;
		//double updatedBalance=currentBalance+amountToBeDeposited2;
		Assertions.assertEquals(updatedBalance,accountService.deposit(amountToBeDeposited2,677474740).getCurrentBalance());
	}

	/*
	 * @Order(2) void testDepositForSavingAccount() {
	 * 
	 * }
	 * 
	 * @Order(3) void testWithdrawForSavingAccount() {
	 * 
	 * }
	 * 
	 * @Order(4) void testWithdrawForCurrentAccount() {
	 * 
	 * }
	 */
}
