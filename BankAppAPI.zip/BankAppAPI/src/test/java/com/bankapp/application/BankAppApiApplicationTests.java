package com.bankapp.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAppApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
