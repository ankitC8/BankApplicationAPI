package com.bankapp.application.controllertests;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.controller.TransactionController;
import com.bankapp.application.entity.Transaction;
import com.bankapp.application.service.TransactionService;

@SpringBootTest(classes = TransactionControllerTest.class)
public class TransactionControllerTest {

	@Mock
	TransactionService transactionService;

	@InjectMocks
	TransactionController transactionController;

	public List<Transaction> transactionList;

	@Test
	@Order(1)
	void TestGetAllProductsInController() {

		transactionList = new ArrayList<Transaction>();

		// Transaction(int, double, TransactionType, double, LocalDate)
		transactionList.add(new Transaction(2, 2000, TransactionType.valueOf("DEPOSIT"), 8000, LocalDate.now()));
		transactionList.add(new Transaction(3, 1500, TransactionType.valueOf("DEPOSIT"), 8990, LocalDate.now()));
		transactionList.add(new Transaction(3, 6500, TransactionType.valueOf("WITHDRAW"), 2997, LocalDate.now()));

		when(transactionService.getAllTransactions()).thenReturn(transactionList);

		ResponseEntity<List<Transaction>> response = transactionController.getTransactions();

		Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
		//Assertions.assertEquals(2, response.getBody().size());//--Failed
		Assertions.assertEquals(3, response.getBody().size());
	}

}
