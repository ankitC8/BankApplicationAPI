package com.bankapp.application.constants;

public enum TransactionType {
	WITHDRAW, DEPOSIT, ENQUIRY
}
