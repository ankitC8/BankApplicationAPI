package com.bankapp.application.service;

import java.util.List;

import com.bankapp.application.dto.AccountDto;
import com.bankapp.application.entity.Account;

public interface AccountService {

	Account createAccount(AccountDto accountDto);

	void deleteAccount(long accountId);

	Account getAccount(long id);

	Account updateAccount(Account account);

	List<Account> getAllAccounts();
	
	Account deposit(double amount,long acccountId);
	Account withdraw(double amount,long accountId);
}
