package com.bankapp.application.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class LoginDto {

	private int customerId;
	private String password;
	private String userName;
}
