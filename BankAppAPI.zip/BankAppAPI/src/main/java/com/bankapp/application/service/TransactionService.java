package com.bankapp.application.service;

import java.util.List;

import com.bankapp.application.dto.TransactionDto;
import com.bankapp.application.entity.Transaction;

public interface TransactionService {

	Transaction createTransaction(TransactionDto Transaction);

	void deleteTransaction(int transactionId);

	List<Transaction> getTransactionsForAccount(long accountId);

	Transaction getTransaction(int transactionId);

	Transaction updateTransaction(Transaction Transaction);

	List<Transaction> getAllTransactions();

	List<Transaction> getAllWithdrawTransactions(long accountId);
	
	List<Transaction> getAllDepositTransactions(long accountId);
}
