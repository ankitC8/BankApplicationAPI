package com.bankapp.application.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.dto.TransactionDto;
import com.bankapp.application.entity.Account;
import com.bankapp.application.entity.Transaction;
import com.bankapp.application.exception.NoSuchAccountException;
import com.bankapp.application.repository.AccountRepository;
import com.bankapp.application.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionRepository transactionRepository;

	private static Logger logger = LoggerFactory.getLogger(TransactionServiceImpl.class);
	@Autowired
	AccountService accountService;

	@Override
	public Transaction createTransaction(TransactionDto transactionDto) {

		Transaction transaction = transactionDto.dtoToEntity(transactionDto);

		// getting account for specified accountId
		Account account = accountService.getAccount(transactionDto.getAccountId());

		// getting transaction list associated for given accountId
		List<Transaction> list = account.getTransactions();
		list.add(transaction);

		// Updating List and then account in DB
		account.setTransactions(list);

		accountService.updateAccount(account);

		// getting last inserted transaction
		// transaction = account.getTransactions().stream().reduce((first, second) ->
		// second).get();
		list = account.getTransactions();
		transaction = list.get(list.size() - 1);
		return transaction;
	}

	@Override
	public void deleteTransaction(int transactionId) {
		transactionRepository.findById(transactionId)
				.orElseThrow(() -> new NoSuchElementException("No such transaction exists " + transactionId));
		transactionRepository.deleteById(transactionId);
	}

	@Override
	public List<Transaction> getTransactionsForAccount(long accountId) {
		accountId = accountService.getAccount(accountId).getAccountId();

		final long localId = accountId;
		// List<Transaction> list=transactionRepository.findByAccountId(accountId);

		List<Transaction> list = accountService.getAllAccounts().stream()
				.filter((account) -> account.getAccountId() == localId).findFirst().get().getTransactions();
		// long id=localAccount.getAccountId();
		// = localAccount.getTransactions();
		return list;
	}

	@Override
	public Transaction getTransaction(int transactionId) {

		return transactionRepository.findById(transactionId)
				.orElseThrow(() -> new NoSuchElementException("No such transaction exists " + transactionId));
	}

	@Override
	public Transaction updateTransaction(Transaction transaction) {

		Transaction localTransaction = transactionRepository.findById(transaction.getTransactionId()).orElseThrow(
				() -> new NoSuchElementException("No such transaction exists " + transaction.getCurrentBalance()));

		localTransaction.setCurrentBalance(transaction.getCurrentBalance());
		localTransaction.setTransactionAmount(transaction.getTransactionAmount());
		localTransaction.setTransactionType(transaction.getTransactionType());
		localTransaction.setTransactionDate(transaction.getTransactionDate());
		return transactionRepository.save(transaction);
	}

	@Override
	public List<Transaction> getAllTransactions() {

		return transactionRepository.findAll();
	}

	@Override
	public List<Transaction> getAllWithdrawTransactions(long accountId) {
		accountService.getAccount(accountId);
		List<Transaction> transactionList = accountService.getAllAccounts().stream()
				.filter((account) -> account.getAccountId() == accountId).findFirst().get().getTransactions();
		transactionList = transactionList.stream()
				.filter((transaction) -> transaction.getTransactionType() == TransactionType.WITHDRAW)
				.collect(Collectors.toList());
		return transactionList;
	}

	@Override
	public List<Transaction> getAllDepositTransactions(long accountId) {
		accountService.getAccount(accountId);

		// transactionRepository.findTransactionByAccountIdAndTransactionType(localAccount.getAccountId(),
		// TransactionType.DEPOSIT);

		List<Transaction> transactionList = accountService.getAllAccounts().stream()
				.filter((account) -> account.getAccountId() == accountId).findFirst().get().getTransactions();
		transactionList = transactionList.stream()
				.filter((transaction) -> transaction.getTransactionType() == TransactionType.DEPOSIT)
				.collect(Collectors.toList());
		return transactionList;
	}
}
