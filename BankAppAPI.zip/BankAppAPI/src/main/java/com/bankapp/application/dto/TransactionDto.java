package com.bankapp.application.dto;

import java.time.LocalDate;

import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.entity.Transaction;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDto {

	private long accountId;
	
	private double transactionAmount;
	private TransactionType transactionType;
	private double currentBalance;
	private LocalDate transactionDate;

	
	public Transaction dtoToEntity(TransactionDto transactionDto) {
		
		Transaction transaction = new Transaction();

		transaction.setTransactionType(transactionDto.getTransactionType());
		transaction.setTransactionAmount(transactionDto.getTransactionAmount());
		transaction.setTransactionDate(transactionDto.getTransactionDate());
		transaction.setCurrentBalance(transactionDto.getCurrentBalance());
		
		return transaction;
	}
}
