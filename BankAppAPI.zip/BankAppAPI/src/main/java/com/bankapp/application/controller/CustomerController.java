package com.bankapp.application.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bankapp.application.dto.LoginDto;
import com.bankapp.application.entity.Customer;
import com.bankapp.application.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "api/customer")
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	//To get all  registered Customers
	@GetMapping(value = "/getAll")
	public ResponseEntity<List<Customer>> getCustomers() {

		return new ResponseEntity<List<Customer>>(customerService.getAllCustomers(), HttpStatus.OK);
	}

	//To get specific customer using it's customerID
	@GetMapping(value = "/get/{customerId}")
	public ResponseEntity<Customer> getCustomer(@PathVariable int customerId) {

		return new ResponseEntity<Customer>(customerService.getCustomer(customerId), HttpStatus.OK);
	}

	//To update customer
	@PutMapping(value = "/update")
	public ResponseEntity<Customer> putCustomer(@Valid @RequestBody Customer customer) {

		return new ResponseEntity<Customer>(customerService.updateCustomer(customer), HttpStatus.OK);
	}

	//To add new customer to the DB
	@PostMapping("/post")
	public ResponseEntity<Customer> postCustomer(@Valid @RequestBody Customer customer) {

		return new ResponseEntity<Customer>(customerService.createCustomer(customer), HttpStatus.OK);
	}
	@DeleteMapping("/delete/{customerId}")
	public ResponseEntity<String> deleteCustomer(@PathVariable int customerId) {
		customerService.deleteCustomer(customerId);
		return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
	}
	
	//Validates customer
	@GetMapping("/login/{customerId}")
	public ResponseEntity login(@PathVariable int customerId,@RequestBody LoginDto loginDto){
		
		//in response we are sending authenticated customer details
		return ResponseEntity.ok(customerService.login(loginDto));
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
		return errors;
	}
	
}
