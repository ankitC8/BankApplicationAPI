package com.bankapp.application.dto;

import java.time.LocalDate;
import java.util.List;

import com.bankapp.application.constants.AccountType;
import com.bankapp.application.constants.StatusType;
import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.entity.Account;
import com.bankapp.application.entity.Transaction;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDto {

	@NotBlank(message = "Please check account Id")
	private long accountId;

	@NotBlank(message = "Please check customer Id")
	private int customerId;

	private double currentBalance;

	@NotBlank(message = "Please check account type")
	private AccountType accountType;

	private StatusType statusType;

	private List<Transaction> transactions;

	public Account dtoToEntity(AccountDto accountDto) {

		Account account = new Account();

		account.setAccountType(accountDto.getAccountType());
		account.setCurrentBalance(accountDto.getCurrentBalance());
		account.setStatusType(accountDto.getStatusType());

		return account;
	}

	public static AccountDto entityToDto(Account account) {

		AccountDto accountDto = new AccountDto();

		accountDto.setAccountId(account.getAccountId());
		accountDto.setAccountType(account.getAccountType());
		accountDto.setCurrentBalance(account.getCurrentBalance());
		accountDto.setStatusType(account.getStatusType());
		accountDto.setTransactions(account.getTransactions());
		// accountDto.setCustomerId(customerId);

		return accountDto;
	}
	public static AccountDto entityToDtoWithoutTransactions(Account account) {

		AccountDto accountDto = new AccountDto();

		accountDto.setAccountId(account.getAccountId());
		accountDto.setAccountType(account.getAccountType());
		accountDto.setCurrentBalance(account.getCurrentBalance());
		accountDto.setStatusType(account.getStatusType());
		//accountDto.setTransactions(account.getTransactions());
		// accountDto.setCustomerId(customerId);

		return accountDto;
	}
}
