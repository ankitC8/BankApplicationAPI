package com.bankapp.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bankapp.application.constants.StatusType;
import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.entity.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

	/*
	 * @Query(value = "from Transaction b where account_id_fk=?1") public
	 * List<Transaction> findByAccountId(long account_id_fk);
	 */

	/*
	 * @Query(value = "from Transaction txn where txn.account_id_fk:accountId and "
	 * + "txn.transaction_type:transactionType") public List<Transaction>
	 * findTransactionByAccountIdAndTransactionType(@Param("accountId") long
	 * accountId,@Param("transactionType") TransactionType type);
	 */

	/*
	 * @Query(
	 * value="select * from transaction where account_Id_fk:accountId and transaction_type:transactionType"
	 * , nativeQuery = true) public List<Transaction>
	 * findTransactionByAccountIdAndTransactionType(@Param("accountId") long
	 * accountId,@Param("transactionType") TransactionType type);
	 */
	
	
}
