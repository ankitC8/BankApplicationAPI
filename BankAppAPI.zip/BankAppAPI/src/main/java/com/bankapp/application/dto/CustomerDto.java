package com.bankapp.application.dto;

import java.util.List;

import com.bankapp.application.constants.AccountType;
import com.bankapp.application.constants.StatusType;
import com.bankapp.application.entity.Account;
import com.bankapp.application.entity.Customer;
import com.bankapp.application.entity.Transaction;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDto {

	private String firstName;
	private String lastName;
	// private String password;
	private String userName;
	private List<Account> accounts;

	public Customer dtoToEntity(CustomerDto customerDto) {
		Customer customer = new Customer();

		customer.setFirstName(customerDto.getFirstName());
		customer.setLastName(customerDto.getLastName());
		customer.setUserName(customerDto.getUserName());
		// customer.setPassword(customerDto.getPassword());
		return customer;
	}

}
