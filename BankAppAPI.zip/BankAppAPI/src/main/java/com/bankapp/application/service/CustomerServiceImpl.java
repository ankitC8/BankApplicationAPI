package com.bankapp.application.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bankapp.application.controller.AccountController;
import com.bankapp.application.dto.LoginDto;
import com.bankapp.application.entity.Customer;
import com.bankapp.application.exception.CustomerAlreadyExistsException;
import com.bankapp.application.exception.NoSuchCustomerException;
import com.bankapp.application.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	private static Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);

	@Override
	public Customer createCustomer(Customer customer) {

		List<Customer> customerList = customerRepository.findAll();

		Optional<Customer> invalidCustomer = customerList.stream()
				.filter((customers) -> customers.getUserName().equals(customer.getUserName())).findFirst();
		if (invalidCustomer.isPresent()) {
			throw new CustomerAlreadyExistsException("Customer Already exists with same user name");
		}

		Customer localCustomer = customerRepository.save(customer);
		logger.info("Customer Created with customer ID " + localCustomer.getCustomerId());
		return localCustomer;
	}

	@Override
	public void deleteCustomer(int customerId) {
		customerRepository.findById(customerId)
				.orElseThrow(() -> new NoSuchCustomerException("NO account PRESENT WITH ID = " + customerId));
		logger.info("Customer deleted with customer ID " + customerId);
		customerRepository.deleteById(customerId);
	}

	@Override
	public Customer getCustomer(int id) {

		return customerRepository.findById(id)
				.orElseThrow(() -> new NoSuchCustomerException("NO account PRESENT WITH ID = " + id));
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		Customer localCustomer = customerRepository.findById(customer.getCustomerId()).orElseThrow(
				() -> new NoSuchCustomerException("NO customer PRESENT WITH ID = " + customer.getCustomerId()));

		localCustomer.setFirstName(customer.getFirstName());
		localCustomer.setLastName(customer.getLastName());
		localCustomer.setPassword(customer.getPassword());
		//localCustomer.setUserName(customer.getUserName());
		logger.info("Customer updated with customer ID " + localCustomer.getCustomerId());
		return customerRepository.save(localCustomer);
	}

	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public Customer login(LoginDto loginDto) {
		// write login logic here

		int customerId = loginDto.getCustomerId();
		String userName = loginDto.getUserName();
		String password = loginDto.getPassword();

		Customer customer = getCustomer(customerId);

		boolean userFlag = customer.getUserName().equalsIgnoreCase(userName);
		boolean passwordFlag = customer.getPassword().equalsIgnoreCase(password);

		if (userFlag && passwordFlag) {
			logger.info("***************\n" + "Customer logged in with user name: " + userName);
			return customer;
		} else {
			throw new NoSuchCustomerException("Invalid Credentials");
		}
	}

}
