package com.bankapp.application.exception;

public class InvalidAmountException extends RuntimeException {

	private String message;

	public InvalidAmountException(String message) {
		super(message);
		this.message = message;
	}

}
