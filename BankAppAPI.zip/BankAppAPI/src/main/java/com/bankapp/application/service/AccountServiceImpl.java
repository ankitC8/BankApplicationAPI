package com.bankapp.application.service;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bankapp.application.constants.AccountType;
import com.bankapp.application.constants.TransactionType;
import com.bankapp.application.dto.AccountDto;
import com.bankapp.application.entity.Account;
import com.bankapp.application.entity.Customer;
import com.bankapp.application.entity.Transaction;
import com.bankapp.application.exception.InvalidAmountException;
import com.bankapp.application.exception.NoSuchAccountException;
import com.bankapp.application.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

	private static Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

	@Value("${account.current.minbalToBeMaintained}")
	double minbalToBeMaintainedCurrent;
	// for withdrawal
	@Value("${account.current.minAmountCanBeWithdrawn}")
	double minAmountCanBeWithdrawnCurrent;
	@Value("${account.current.maxAmountCanBeWithdrawn}")
	double maxAmountCanBeWithdrawnCurrent;
	// for deposite
	@Value("${account.current.minAmountCanBeDeposited}")
	double minAmountCanBeDepositedCurrent;
	@Value("${account.current.maxAmountCanBeDeposited}")
	double maxAmountCanBeDepositedCurrent;

	@Value("${account.savings.minbalToBeMaintained}")
	double minbalToBeMaintainedSavings;
	// for withdrawal
	@Value("${account.savings.minAmountCanBeWithdrawn}")
	double minAmountCanBeWithdrawnSavings;
	@Value("${account.savings.maxAmountCanBeWithdrawn}")
	double maxAmountCanBeWithdrawnSavings;
	// for deposite
	@Value("${account.savings.minAmountCanBeDeposited}")
	double minAmountCanBeDepositedSavings;
	@Value("${account.savings.maxAmountCanBeDeposited}")
	double maxAmountCanBeDepositedSavings;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	CustomerService customerService;

	@Override
	public Account createAccount(AccountDto accountDto) {

		Account account = accountDto.dtoToEntity(accountDto);

		Customer customer = customerService.getCustomer(accountDto.getCustomerId());

		List<Account> list = customer.getAccounts();

		list.add(account);

		customer.setAccounts(list);
		customerService.updateCustomer(customer);

		
		list = customer.getAccounts();
		account = list.get(list.size() - 1);
		// account=customerService.getCustomer(accountDto.getCustomerId()).getAccounts().stream().reduce((a,b)->b).get();
		logger.info("New account created with Id" + account.getAccountId());
		return account;
	}

	@Override
	public void deleteAccount(long accountId) {

		accountRepository.findById(accountId)
				.orElseThrow(() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + accountId));
		logger.info("Account Deleted with id" + accountId);
		accountRepository.deleteById(accountId);

	}

	@Override
	public Account getAccount(long id) {

		return accountRepository.findById(id)
				.orElseThrow(() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + id));
	}

	@Override
	public Account updateAccount(Account account) {

		Account localAccount = accountRepository.findById(account.getAccountId()).orElseThrow(
				() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + account.getAccountId()));
		localAccount.setAccountType(account.getAccountType());
		localAccount.setCurrentBalance(account.getCurrentBalance());
		localAccount.setStatusType(account.getStatusType());
		// localAccount.setTransactions(acc);
		Account finalAccount = accountRepository.save(localAccount);
		;
		logger.info("Account updated with id" + account.getAccountId());
		return finalAccount;
	}

	@Override
	public List<Account> getAllAccounts() {

		return accountRepository.findAll();
	}

	@Override
	public Account deposit(double amount, long accountId) {
		// put deposite logic according to account type

		Account localAccount = accountRepository.findById(accountId)
				.orElseThrow(() -> new NoSuchAccountException("No account Exist for given accountId" + accountId));

		double finalAmount = localAccount.getCurrentBalance();
		AccountType accountType = localAccount.getAccountType();

		// deposit logic;
		if (accountType.equals(AccountType.SAVINGS)) {
			// for savings you can't deposit amount more than 50,000 and less than 1000
			if (amount >= minAmountCanBeDepositedSavings && amount <= maxAmountCanBeDepositedSavings) {
				finalAmount += amount;
				localAccount.setCurrentBalance(finalAmount);

				// creating transaction to autosave Deposite transaction
				Transaction transaction = new Transaction();

				transaction.setCurrentBalance(localAccount.getCurrentBalance());
				transaction.setTransactionDate(LocalDate.now());
				transaction.setTransactionType(TransactionType.DEPOSIT);
				transaction.setTransactionAmount(amount);

				localAccount.getTransactions().add(transaction);

				// updating account
				logger.info(amount + " Amount Deposited in account with id " + localAccount.getAccountId());
				return updateAccount(localAccount);

			} else {

				throw new InvalidAmountException("Invalid Amount to be credited in Saving Account: " + amount);
			}

		} else if (accountType.equals(AccountType.CURRENT)) {

			// for current account amount for deposite should be 100 to 10 lac for single
			// transaction

			if (amount >= minAmountCanBeDepositedCurrent && amount <= maxAmountCanBeDepositedCurrent) {
				finalAmount += amount;
				localAccount.setCurrentBalance(finalAmount);

				// creating transaction to autosave Deposite transaction
				Transaction transaction = new Transaction();

				transaction.setCurrentBalance(localAccount.getCurrentBalance());
				transaction.setTransactionDate(LocalDate.now());
				transaction.setTransactionType(TransactionType.DEPOSIT);
				transaction.setTransactionAmount(amount);

				localAccount.getTransactions().add(transaction);

				// updating account
				logger.info(amount + " Amount Deposited in account with id " + localAccount.getAccountId());
				return updateAccount(localAccount);

			} else {
				throw new InvalidAmountException("Invalid Amount to be credited in Current Account: " + amount);
			}
		} else {
			throw new NoSuchAccountException("Please Check account Type");
		}

	}

	@Override
	public Account withdraw(double amount, long accountId) {
		// withdraw method logic according to account type

		Account localAccount = accountRepository.findById(accountId)
				.orElseThrow(() -> new NoSuchAccountException("No account Exist for given accountId" + accountId));

		double finalAmount = localAccount.getCurrentBalance();
		AccountType accountType = localAccount.getAccountType();

		if (accountType.equals(AccountType.SAVINGS)) {
			// for savings you can't withdraw amount more than 1,00,000 and less than 1000
			// and account must have 5000 maintained as min balance

			// double minBalance;
			double currentBalance = localAccount.getCurrentBalance();
			double accountedBalance = currentBalance - amount;
			if(accountedBalance < minbalToBeMaintainedSavings)
				throw new InvalidAmountException("Insufficient Funds");
			
			if (amount >= minAmountCanBeWithdrawnSavings && amount <= maxAmountCanBeWithdrawnSavings) {

				finalAmount -= amount;
				localAccount.setCurrentBalance(finalAmount);

				// creating transaction to autosave Deposite transaction
				Transaction transaction = new Transaction();

				transaction.setCurrentBalance(localAccount.getCurrentBalance());
				transaction.setTransactionDate(LocalDate.now());
				transaction.setTransactionType(TransactionType.WITHDRAW);
				transaction.setTransactionAmount(amount);

				localAccount.getTransactions().add(transaction);

				// updating account
				logger.info(amount + " Amount withdrawn from account with id " + localAccount.getAccountId());
				return updateAccount(localAccount);

			} else {

				throw new InvalidAmountException("Invalid Amount to be withdraw from Saving Account: " + amount);
			}

		} else if (accountType.equals(AccountType.CURRENT)) {

			// for current account amount for withdraw shouldn't be greater than 10,00,000
			// and less than min bal of -10000

			// final double minBalance = -10000;
			double currentBalance = localAccount.getCurrentBalance();
			double accountedBalance = currentBalance - amount;
			if(accountedBalance < minbalToBeMaintainedCurrent)
				throw new InvalidAmountException("Insufficient Funds");
			if (amount >= minAmountCanBeDepositedCurrent && amount <= maxAmountCanBeDepositedCurrent) {
				finalAmount -= amount;
				localAccount.setCurrentBalance(finalAmount);

				// creating transaction to autosave Deposite transaction
				Transaction transaction = new Transaction();

				transaction.setCurrentBalance(localAccount.getCurrentBalance());
				transaction.setTransactionDate(LocalDate.now());
				transaction.setTransactionType(TransactionType.WITHDRAW);
				transaction.setTransactionAmount(amount);

				localAccount.getTransactions().add(transaction);

				// updating account
				logger.info(amount + " Amount withdrawn from account with id " + localAccount.getAccountId());
				return updateAccount(localAccount);

			} else {
				throw new InvalidAmountException("Invalid Amount to be withdraw from Current Account: " + amount);
			}
		} else {
			throw new NoSuchAccountException("Please Check account Type");
		}

	}
}
