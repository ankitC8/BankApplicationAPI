package com.bankapp.application.exception;

public class NoSuchAccountException extends RuntimeException {

	private String message;

	public NoSuchAccountException(String message) {

		super(message);
		this.message = message;
	}

}
