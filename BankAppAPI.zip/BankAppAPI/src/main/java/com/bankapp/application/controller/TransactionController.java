package com.bankapp.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bankapp.application.dto.TransactionDto;
import com.bankapp.application.entity.Transaction;
import com.bankapp.application.service.TransactionService;

@RestController
@RequestMapping(value = "api/transaction")
public class TransactionController {

	@Autowired
	TransactionService transactionService;

	@GetMapping(value = "/getAll")
	public ResponseEntity<List<Transaction>> getTransactions() {

		return new ResponseEntity<List<Transaction>>(transactionService.getAllTransactions(), HttpStatus.OK);
	}

	@GetMapping(value = "/get/{transactionId}")
	public ResponseEntity<Transaction> getTransaction(@PathVariable int transactionId) {

		return new ResponseEntity<Transaction>(transactionService.getTransaction(transactionId), HttpStatus.OK);
	}

	@GetMapping(value = "/getByAccountId/{accountId}")
	public ResponseEntity<List<Transaction>> getTransactionsForAccount(@PathVariable long accountId) {

		return new ResponseEntity<List<Transaction>>(transactionService.getTransactionsForAccount(accountId),
				HttpStatus.OK);
	}

	@PutMapping(value = "/update")
	public ResponseEntity<Transaction> putTransaction(@RequestBody Transaction transaction) {

		return new ResponseEntity<Transaction>(transactionService.updateTransaction(transaction), HttpStatus.ACCEPTED);
	}

	@PostMapping("/post")
	public ResponseEntity<Transaction> postTransaction(@RequestBody TransactionDto transactionDto) {

		return new ResponseEntity<Transaction>(transactionService.createTransaction(transactionDto),
				HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{transactionId}")
	public ResponseEntity<String> deleteTransaction(@PathVariable int transactionId) {
		transactionService.deleteTransaction(transactionId);
		return new ResponseEntity<String>("Deleted Successfully", HttpStatus.OK);
	}

	@GetMapping("/getDeposit/{accountId}")
	public ResponseEntity<List<Transaction>> getTransactionForDeposit(@PathVariable long accountId) {
		List<Transaction> transactionList = transactionService.getAllDepositTransactions(accountId);
		return new ResponseEntity<List<Transaction>>(transactionList, HttpStatus.OK);
	}

	@GetMapping("/getWithdraw/{accountId}")
	public ResponseEntity<List<Transaction>> getTransactionForWithdraw(@PathVariable long accountId) {
		List<Transaction> transactionList = transactionService.getAllWithdrawTransactions(accountId);
		return new ResponseEntity<List<Transaction>>(transactionList, HttpStatus.OK);
	}
}
