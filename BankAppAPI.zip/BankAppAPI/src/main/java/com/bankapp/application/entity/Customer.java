package com.bankapp.application.entity;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
public class Customer implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;

	@Pattern(regexp = "^[a-zA-Z]{2,15}$", message = "First Name Should Be Valid")
	private String firstName;

	@Pattern(regexp = "^[a-zA-Z]{2,15}$", message = "Last Name Should Be Valid")
	private String lastName;

	@Pattern(regexp = "^[a-zA-Z0-9_-]{4,16}$", message = "Password Should Be Valid")
	private String password;

	// Basic Email regular expression
	@Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "User Name Should Be Valid")
	private String userName;

	@OneToMany(targetEntity = Account.class, cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "customerId_fk")
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private List<Account> accounts;
}
