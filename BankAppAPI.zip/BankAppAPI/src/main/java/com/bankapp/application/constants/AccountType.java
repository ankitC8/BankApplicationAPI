package com.bankapp.application.constants;

public enum AccountType {

	SAVINGS, CURRENT
}
