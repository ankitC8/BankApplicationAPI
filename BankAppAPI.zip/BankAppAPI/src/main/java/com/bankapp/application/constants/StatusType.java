package com.bankapp.application.constants;

public enum StatusType {

	ACTIVE, DEACTIVE,
}
