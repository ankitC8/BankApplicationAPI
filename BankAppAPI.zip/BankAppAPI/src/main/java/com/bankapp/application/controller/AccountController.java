package com.bankapp.application.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bankapp.application.dto.AccountDto;
import com.bankapp.application.entity.Account;
import com.bankapp.application.service.AccountService;

import jakarta.validation.Valid;


@RestController
@RequestMapping(value = "/api/account")
public class AccountController {

	@Autowired
	AccountService accountService;

	@GetMapping(value = "/getAll")
	public ResponseEntity<List<Account>> getAccounts() {
		return new ResponseEntity<List<Account>>(accountService.getAllAccounts(), HttpStatus.OK);
	}

	@GetMapping(value = "/getDto/{accountId}")
	public ResponseEntity<AccountDto> getAccountDto(@PathVariable long accountId) {

		Account account = accountService.getAccount(accountId);
		AccountDto accountDto = AccountDto.entityToDto(account);
		// accountService.getAccount(accountId)
		return new ResponseEntity<AccountDto>(accountDto, HttpStatus.OK);
	}

	@GetMapping(value = "/getDtoWithoutTransactions/{accountId}")
	public ResponseEntity<AccountDto> getAccountDtoWithoutTransactions(@PathVariable long accountId) {

		Account account = accountService.getAccount(accountId);
		AccountDto accountDto = AccountDto.entityToDtoWithoutTransactions(account);
		// accountService.getAccount(accountId)
		return new ResponseEntity<AccountDto>(accountDto, HttpStatus.OK);
	}

	@GetMapping(value = "/get/{accountId}")
	public ResponseEntity<Account> getAccount(@PathVariable long accountId) {

		return new ResponseEntity<Account>(accountService.getAccount(accountId), HttpStatus.OK);
	}

	@PutMapping(value = "/update")
	public ResponseEntity<Account> putAccount(@Valid @RequestBody Account account) {

		return new ResponseEntity<Account>(accountService.updateAccount(account), HttpStatus.ACCEPTED);
	}

	@PostMapping("/post")
	public ResponseEntity<Account> postAccount(@RequestBody AccountDto accountDto) {

		return new ResponseEntity<Account>(accountService.createAccount(accountDto), HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{accountId}")
	public ResponseEntity<String> deleteAccount(@PathVariable long accountId) {
		accountService.deleteAccount(accountId);
		return new ResponseEntity<String>("Deleted Successfully", HttpStatus.OK);
	}

	// Deposit Withdraw methods

	@PostMapping("/deposit/{amount}/{accountId}")
	public ResponseEntity<Account> deposit(@PathVariable double amount, @PathVariable long accountId) {

		return new ResponseEntity<Account>(accountService.deposit(amount, accountId), HttpStatus.ACCEPTED);
	}

	@PostMapping("/withdraw/{amount}/{accountId}")
	public ResponseEntity<Account> withdraw(@PathVariable double amount, @PathVariable long accountId) {

		return new ResponseEntity<Account>(accountService.withdraw(amount, accountId), HttpStatus.ACCEPTED);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
		return errors;
	}
}
