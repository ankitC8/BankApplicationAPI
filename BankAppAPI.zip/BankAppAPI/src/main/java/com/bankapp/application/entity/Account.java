package com.bankapp.application.entity;

import java.io.Serializable;
import java.util.List;

import com.bankapp.application.constants.AccountType;
import com.bankapp.application.constants.StatusType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
public class Account implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long accountId;

	private double currentBalance;

	@Enumerated(EnumType.STRING)
	private AccountType accountType;

	//can be used in order to deactivate/activate account
	@Enumerated(EnumType.STRING)
	private StatusType statusType;
	
	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name="customerId_fk") private Customer customer;
	 * 
	 */
	@OneToMany(targetEntity = Transaction.class, cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "accountId_fk")
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private List<Transaction> transactions;

}
