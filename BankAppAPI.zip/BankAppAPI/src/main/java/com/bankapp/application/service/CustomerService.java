package com.bankapp.application.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.bankapp.application.dto.LoginDto;
import com.bankapp.application.entity.Customer;

public interface CustomerService {

	Customer createCustomer(Customer customer);

	void deleteCustomer(int customerId);

	Customer getCustomer(int id);

	Customer updateCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer login(LoginDto loginDto);
}
