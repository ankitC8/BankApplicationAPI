package com.bankapp.application.exception;

public class NoSuchCustomerException extends RuntimeException {

	private String message;

	public NoSuchCustomerException(String message) {
		super(message);
		this.message = message;
	}

}
